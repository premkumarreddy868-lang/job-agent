"""One place for all AI calls.
If GEMINI_API_KEY is set, uses Google Gemini (free tier).
Otherwise uses Claude via ANTHROPIC_API_KEY (paid).
"""
import os
import time

PROVIDER = "gemini" if os.getenv("GEMINI_API_KEY") else "anthropic"
_client = None


def _call(prompt, max_tokens):
    global _client
    if PROVIDER == "gemini":
        from google import genai

        if _client is None:
            _client = genai.Client()  # reads GEMINI_API_KEY
        model = os.getenv("JOB_AGENT_MODEL", "gemini-2.5-flash-lite")
        resp = _client.models.generate_content(model=model, contents=prompt)
        return resp.text or ""

    import anthropic

    if _client is None:
        _client = anthropic.Anthropic()
    model = os.getenv("JOB_AGENT_MODEL", "claude-sonnet-5-5")
    resp = _client.messages.create(
        model=model, max_tokens=max_tokens, messages=[{"role": "user", "content": prompt}]
    )
    return resp.content[0].text


def ask(prompt, max_tokens=500):
    for attempt in range(5):
        try:
            text = _call(prompt, max_tokens)
            if PROVIDER == "gemini":
                time.sleep(5)  # stay under the free per-minute limit
            return text
        except Exception as e:
            msg = str(e)
            if "429" in msg or "RESOURCE_EXHAUSTED" in msg or "503" in msg:
                wait = 20 * (attempt + 1)
                print(f"Rate limit or busy. Waiting {wait} seconds...")
                time.sleep(wait)
            else:
                raise
    raise RuntimeError("Too many rate-limit errors. Try again later.")


def ask_json(prompt, max_tokens=500):
    """Ask for JSON and return a dict, or None if the reply is not valid JSON."""
    import json

    text = ask(prompt, max_tokens)
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        return None
    try:
        return json.loads(text[start : end + 1])
    except Exception:
        return None
