import llm


def tailor(profile, job):
    prompt = f"""Write application text for this candidate and job.

CANDIDATE (use ONLY facts written here. Never invent experience, skills or numbers):
{profile}

JOB:
Title: {job['title']}
Details: {job['snippet']}

Write:
1. "summary": a 2-sentence resume summary for this job.
2. "cover_note": a short cover note, max 90 words, simple English, no fluff.

Reply with JSON only: {{"summary": "...", "cover_note": "..."}}"""
    data = llm.ask_json(prompt, max_tokens=500)
    try:
        return data["summary"], data["cover_note"]
    except Exception:
        return None, None
