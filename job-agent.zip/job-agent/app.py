import html

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, RedirectResponse

import db

app = FastAPI()
db.init()

PAGE = """<html><head><title>Job tracker</title><style>
body{font-family:sans-serif;max-width:800px;margin:20px auto;padding:0 12px}
.card{border:1px solid #ccc;border-radius:8px;padding:12px;margin:12px 0}
.applied{background:#eef8ee} textarea{width:100%;height:70px}
button,a.btn{padding:6px 10px;margin-right:6px;cursor:pointer}
</style></head><body><h1>Job tracker</h1>__CARDS__
<script>function copyText(id){navigator.clipboard.writeText(document.getElementById(id).value)}</script>
</body></html>"""


@app.get("/", response_class=HTMLResponse)
def home():
    cards = ""
    for j in db.list_jobs():
        e = lambda x: html.escape(x or "")
        text_block = ""
        if j["summary"]:
            text_block = (
                f"<p><b>Resume summary</b></p><textarea id='s{j['id']}'>{e(j['summary'])}</textarea>"
                f"<button onclick=\"copyText('s{j['id']}')\">Copy summary</button>"
                f"<p><b>Cover note</b></p><textarea id='c{j['id']}'>{e(j['cover_note'])}</textarea>"
                f"<button onclick=\"copyText('c{j['id']}')\">Copy note</button>"
            )
        cls = "card applied" if j["status"] == "applied" else "card"
        done = f"<p>Applied on {e(j['applied_at'])}</p>" if j["status"] == "applied" else ""
        cards += f"""<div class='{cls}'>
            <b>[{j['score']}] {e(j['title'])}</b><p>{e(j['reason'])}</p>{text_block}{done}
            <p><a class='btn' href='{j['url']}' target='_blank'>Open job</a>
            <form method='post' action='/status/{j['id']}/applied' style='display:inline'><button>Mark applied</button></form>
            <form method='post' action='/status/{j['id']}/skipped' style='display:inline'><button>Skip</button></form></p>
        </div>"""
    return PAGE.replace("__CARDS__", cards or "<p>No jobs yet. Run main.py first.</p>")


@app.post("/status/{job_id}/{status}")
def set_status(job_id: str, status: str):
    if status in ("applied", "skipped"):
        db.set_status(job_id, status)
    return RedirectResponse("/", status_code=303)
