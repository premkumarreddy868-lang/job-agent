import llm


def score_job(profile, job):
    prompt = f"""You are a strict job-match reviewer.

CANDIDATE:
{profile}

JOB (from an email alert, so details are limited):
Title: {job['title']}
Details: {job['snippet']}

Score the match from 0 to 100. Be strict: senior roles, wrong field or wrong skills should score low.
Reply with JSON only: {{"score": <int>, "reason": "<one short sentence>"}}"""
    data = llm.ask_json(prompt, max_tokens=200)
    try:
        return int(data["score"]), str(data["reason"])
    except Exception:
        return 0, "Could not parse model reply"
