import sqlite3

conn = sqlite3.connect("jobs.db", check_same_thread=False)
conn.row_factory = sqlite3.Row


def init():
    conn.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            title TEXT,
            snippet TEXT,
            url TEXT,
            score INTEGER,
            reason TEXT,
            summary TEXT,
            cover_note TEXT,
            status TEXT DEFAULT 'new',      -- new / applied / skipped
            found_at TEXT DEFAULT CURRENT_TIMESTAMP,
            applied_at TEXT,
            digest_sent INTEGER DEFAULT 0,
            followup_sent INTEGER DEFAULT 0
        )
    """)
    # If you ran the older version, add the new columns
    for col in ["summary TEXT", "cover_note TEXT",
                "digest_sent INTEGER DEFAULT 0", "followup_sent INTEGER DEFAULT 0"]:
        try:
            conn.execute(f"ALTER TABLE jobs ADD COLUMN {col}")
        except sqlite3.OperationalError:
            pass
    conn.commit()


def add_job(job):
    cur = conn.execute(
        "INSERT OR IGNORE INTO jobs (id, title, snippet, url) VALUES (?, ?, ?, ?)",
        (job["id"], job["title"], job["snippet"], job["url"]),
    )
    conn.commit()
    return cur.rowcount == 1


def unscored():
    return conn.execute("SELECT * FROM jobs WHERE score IS NULL").fetchall()


def save_score(job_id, score, reason):
    conn.execute("UPDATE jobs SET score=?, reason=? WHERE id=?", (score, reason, job_id))
    conn.commit()


def to_tailor(min_score=70):
    return conn.execute(
        "SELECT * FROM jobs WHERE score >= ? AND summary IS NULL AND status='new'", (min_score,)
    ).fetchall()


def save_tailored(job_id, summary, cover_note):
    conn.execute("UPDATE jobs SET summary=?, cover_note=? WHERE id=?", (summary, cover_note, job_id))
    conn.commit()


def to_digest(min_score=60, limit=10):
    return conn.execute(
        "SELECT * FROM jobs WHERE status='new' AND digest_sent=0 AND score >= ? "
        "ORDER BY score DESC LIMIT ?", (min_score, limit),
    ).fetchall()


def mark_digest_sent(ids):
    for i in ids:
        conn.execute("UPDATE jobs SET digest_sent=1 WHERE id=?", (i,))
    conn.commit()


def set_status(job_id, status):
    if status == "applied":
        conn.execute("UPDATE jobs SET status='applied', applied_at=CURRENT_TIMESTAMP WHERE id=?", (job_id,))
    else:
        conn.execute("UPDATE jobs SET status=? WHERE id=?", (status, job_id))
    conn.commit()


def followups_due(days=7):
    return conn.execute(
        "SELECT * FROM jobs WHERE status='applied' AND followup_sent=0 "
        "AND applied_at <= datetime('now', ?)", (f"-{days} days",),
    ).fetchall()


def mark_followup_sent(ids):
    for i in ids:
        conn.execute("UPDATE jobs SET followup_sent=1 WHERE id=?", (i,))
    conn.commit()


def list_jobs(min_score=60):
    return conn.execute(
        "SELECT * FROM jobs WHERE score >= ? AND status != 'skipped' "
        "ORDER BY (status='applied'), score DESC", (min_score,),
    ).fetchall()
