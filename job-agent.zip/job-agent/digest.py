import base64
import html
from email.mime.text import MIMEText

import db
import gmail_reader

SITE = "http://localhost:8000"   # your tracking page (works on your own computer)


def send_email(service, to, subject, html_body):
    msg = MIMEText(html_body, "html")
    msg["to"] = to
    msg["subject"] = subject
    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    service.users().messages().send(userId="me", body={"raw": raw}).execute()


def send_digest():
    jobs = db.to_digest()
    followups = db.followups_due()
    if not jobs and not followups:
        print("Nothing to send today")
        return

    body = ""
    if jobs:
        body += "<h2>Top jobs today</h2>"
        for j in jobs:
            body += (
                f"<p><b>[{j['score']}] {html.escape(j['title'])}</b><br>"
                f"{html.escape(j['reason'] or '')}<br>"
                f"<a href='{j['url']}'>Open job</a></p>"
            )
    if followups:
        body += "<h2>Follow up (applied 7+ days ago)</h2>"
        for j in followups:
            body += f"<p>{html.escape(j['title'])} - <a href='{j['url']}'>job link</a></p>"
    body += f"<p>Cover notes and buttons: <a href='{SITE}'>{SITE}</a></p>"

    service = gmail_reader.get_service()
    me = service.users().getProfile(userId="me").execute()["emailAddress"]
    send_email(service, me, f"Job digest: {len(jobs)} new, {len(followups)} follow-ups", body)
    db.mark_digest_sent([j["id"] for j in jobs])
    db.mark_followup_sent([j["id"] for j in followups])
    print(f"Digest sent to {me}")
