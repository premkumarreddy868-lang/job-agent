import db
import digest
import gmail_reader
import scorer
import tailor


def run():
    db.init()
    profile = open("my_profile.txt").read()

    # Step 1: read job alert emails
    jobs = gmail_reader.fetch_jobs(days=2)
    new = sum(db.add_job(j) for j in jobs)
    print(f"Found {len(jobs)} jobs, {new} are new")

    # Step 2: score
    for job in db.unscored():
        score, reason = scorer.score_job(profile, job)
        db.save_score(job["id"], score, reason)

    # Step 3: write tailored text for good matches
    for job in db.to_tailor():
        summary, note = tailor.tailor(profile, job)
        if summary:
            db.save_tailored(job["id"], summary, note)

    # Step 4 + 6: daily email with new jobs and follow-up reminders
    digest.send_digest()


if __name__ == "__main__":
    run()
