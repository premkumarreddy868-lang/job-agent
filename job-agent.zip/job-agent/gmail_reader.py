import base64
import os
import re

from bs4 import BeautifulSoup
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.send",
]
# Check this sender in your own inbox. Change it if your alerts come from another address.
ALERT_QUERY = "from:jobalerts-noreply@linkedin.com newer_than:{days}d"


def get_service():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as f:
            f.write(creds.to_json())
    return build("gmail", "v1", credentials=creds)


def _find_html(payload):
    if payload.get("mimeType") == "text/html" and payload["body"].get("data"):
        return base64.urlsafe_b64decode(payload["body"]["data"]).decode("utf-8", "ignore")
    for part in payload.get("parts", []):
        html = _find_html(part)
        if html:
            return html
    return None


def _parse_jobs(html):
    soup = BeautifulSoup(html, "html.parser")
    jobs = {}
    for a in soup.find_all("a", href=True):
        m = re.search(r"/jobs/view/(\d+)", a["href"])
        if not m:
            continue
        job_id = m.group(1)
        title = a.get_text(" ", strip=True)
        if not title or job_id in jobs:
            continue
        # Grab nearby text (company, location) from the parent blocks
        node, snippet = a, ""
        for _ in range(3):
            node = node.parent
            if node is None:
                break
            snippet = node.get_text(" ", strip=True)
            if len(snippet) > 40:
                break
        jobs[job_id] = {
            "id": job_id,
            "title": title,
            "snippet": snippet[:300],
            "url": f"https://www.linkedin.com/jobs/view/{job_id}",
        }
    return list(jobs.values())


def fetch_jobs(days=2):
    service = get_service()
    res = service.users().messages().list(
        userId="me", q=ALERT_QUERY.format(days=days), maxResults=50
    ).execute()
    found = {}
    for m in res.get("messages", []):
        msg = service.users().messages().get(userId="me", id=m["id"], format="full").execute()
        html = _find_html(msg["payload"])
        if html:
            for job in _parse_jobs(html):
                found[job["id"]] = job
    return list(found.values())
